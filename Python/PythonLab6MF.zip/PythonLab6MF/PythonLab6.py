#Lab 6 Maxwell Floyd
#10/30/19
def main():
    CorrectAnswersList = [a, c, a, a, d, b, c, a, c, b, a, d, c, a , d, c, b, b, d, a]
    return CorrectAnswersList
    StudentFileRead();

def StudentFileRead(CorrectAnswersList):
    studentRead = open('studentAnswers.dat', 'r')
    for CorrectAnswersList in range (1, 21):
        if studentAnswers.dat == CorrectAnswersList:
            print("100%, Congrats!")
        else:
            print("X")